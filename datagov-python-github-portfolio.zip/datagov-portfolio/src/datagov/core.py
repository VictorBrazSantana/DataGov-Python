"""DataGov Portfolio: reproducible synthetic governance demonstration."""
from __future__ import annotations
import json
import re
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

PII = {'nome':'IDENTIFICACAO','cpf':'CPF','email':'EMAIL','telefone':'TELEFONE','data_nascimento':'NASCIMENTO','cep':'LOCALIZACAO','endereco':'LOCALIZACAO','ip_origem':'IP'}
DOMAINS = {'cliente':'Cadastro','pedido':'Vendas','pagamento':'Financeiro','atendimento':'Relacionamento'}
RULES = {'clientes':{'key':'id_cliente','required':['id_cliente','nome','cpf','email','data_cadastro'],'checks':{'cpf':'cpf','email':'email','idade':'age'}},'pedidos':{'key':'id_pedido','required':['id_pedido','id_cliente','data_pedido','valor_total'],'checks':{'valor_total':'nonnegative'}},'pagamentos':{'key':'id_pagamento','required':['id_pagamento','id_pedido','valor_pago'],'checks':{'valor_pago':'nonnegative'}},'atendimentos':{'key':'id_atendimento','required':['id_atendimento','id_cliente','data_abertura'],'checks':{}}}

def cpf_valid(v):
    if pd.isna(v): return False
    s=re.sub(r'\D','',str(v))
    if len(s)!=11 or len(set(s))==1:return False
    for length in (9,10):
        check=(sum(int(s[i])*(length+1-i) for i in range(length))*10)%11
        if check==10:check=0
        if check!=int(s[length]):return False
    return True

def validate_value(value,kind):
    if pd.isna(value):return False
    if kind=='cpf':return cpf_valid(value)
    if kind=='email':return bool(re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+',str(value)))
    if kind=='age':
        v=pd.to_numeric(value,errors='coerce');return bool(pd.notna(v) and 0<=v<=120)
    if kind=='nonnegative':
        v=pd.to_numeric(value,errors='coerce');return bool(pd.notna(v) and v>=0)
    return True

def analyze(data:dict[str,pd.DataFrame],output:Path):
    output=Path(output);output.mkdir(parents=True,exist_ok=True)
    profiles=[];rules=[];catalog=[];issues=[];lineage=[];assets=[]
    for dataset,df in data.items():
        config=RULES.get(dataset,{'key':None,'required':[],'checks':{}})
        if df.columns.duplicated().any():raise ValueError(f'Colunas duplicadas: {dataset}')
        for col in df.columns:
            series=df[col]; total=len(df); null=int(series.isna().sum());unique=int(series.nunique(dropna=True));completeness=round(100*(total-null)/total,2) if total else None
            classification=PII.get(col,'REVISAO_MANUAL' if any(x in col.lower() for x in ('documento','identidade','token')) else 'NAO_IDENTIFICADO')
            domain=DOMAINS.get(dataset,'Não definido')
            profiles.append({'dataset':dataset,'coluna':col,'tipo':str(series.dtype),'registros':total,'nulos':null,'distintos':unique,'completude_pct':completeness,'duplicados_valor':int(series.dropna().duplicated().sum())})
            catalog.append({'asset_id':f'{dataset}.{col}','dataset':dataset,'coluna':col,'dominio':domain,'classificacao_indicativa':classification,'revisao_humana':classification!='NAO_IDENTIFICADO','owner':'A DEFINIR','steward':'A DEFINIR','finalidade':'A DEFINIR','base_legal':'A AVALIAR','retencao':'A DEFINIR','controle_acesso':'A VALIDAR','descricao':f'Campo {col} do dataset {dataset}','fonte':'dataset sintetico gerado localmente'})
            lineage.append({'origem':f'data/{dataset}.csv','destino':f'reports/catalogo.csv','asset_id':f'{dataset}.{col}','transformacao':'leitura e analise de metadados','tipo':'lineage demonstrativo observado no pipeline'})
            if col in config['required']:
                passed=total-null;rate=round(100*passed/total,2) if total else None
                rules.append({'dataset':dataset,'coluna':col,'regra':'obrigatoriedade','avaliados':total,'falhas':null,'taxa_sucesso_pct':rate,'status':'OK' if null==0 and total>0 else 'NOK'})
                for idx in df.index[series.isna()]:issues.append({'dataset':dataset,'linha':int(idx)+2,'coluna':col,'regra':'obrigatoriedade','problema':'valor ausente'})
            if col in config['checks']:
                kind=config['checks'][col];non_null=series.dropna();bad=non_null.index[~non_null.map(lambda x:validate_value(x,kind))];rate=round(100*(len(non_null)-len(bad))/len(non_null),2) if len(non_null) else None
                rules.append({'dataset':dataset,'coluna':col,'regra':f'validade_{kind}','avaliados':len(non_null),'falhas':len(bad),'taxa_sucesso_pct':rate,'status':'OK' if len(bad)==0 and len(non_null)>0 else 'NOK'})
                for idx in bad:issues.append({'dataset':dataset,'linha':int(idx)+2,'coluna':col,'regra':f'validade_{kind}','problema':'valor invalido (nao exportado)'})
        key=config['key']
        if key and key in df:
            bad=df.index[df[key].duplicated(keep=False)&df[key].notna()];rules.append({'dataset':dataset,'coluna':key,'regra':'chave_unica','avaliados':len(df),'falhas':len(bad),'taxa_sucesso_pct':round(100*(len(df)-len(bad))/len(df),2) if len(df) else None,'status':'OK' if len(bad)==0 and len(df)>0 else 'NOK'})
            for idx in bad:issues.append({'dataset':dataset,'linha':int(idx)+2,'coluna':key,'regra':'chave_unica','problema':'chave duplicada'})
        assets.append({'dataset':dataset,'registros':len(df),'colunas':len(df.columns),'origem':f'data/{dataset}.csv','natureza':'SINTETICO'})
    for child,parent,fk,pk in [('pedidos','clientes','id_cliente','id_cliente'),('pagamentos','pedidos','id_pedido','id_pedido'),('atendimentos','clientes','id_cliente','id_cliente')]:
        if child in data and parent in data and fk in data[child] and pk in data[parent]:
            df=data[child]; missing=df[fk].notna()&~df[fk].isin(data[parent][pk].dropna());n=int(missing.sum());rules.append({'dataset':child,'coluna':fk,'regra':f'integridade_referencial_{parent}','avaliados':int(df[fk].notna().sum()),'falhas':n,'taxa_sucesso_pct':round(100*(1-n/max(1,int(df[fk].notna().sum()))),2),'status':'NOK' if n else 'OK'})
            for idx in df.index[missing]:issues.append({'dataset':child,'linha':int(idx)+2,'coluna':fk,'regra':'integridade_referencial','problema':f'FK sem correspondencia em {parent}'})
    reports={'perfil':profiles,'regras_qualidade':rules,'catalogo':catalog,'problemas':issues,'linhagem':lineage,'ativos':assets}
    for name,records in reports.items():pd.DataFrame(records).to_csv(output/f'{name}.csv',index=False,encoding='utf-8-sig')
    evaluated=[r for r in rules if r['status'] in ('OK','NOK')];passed=sum(r['status']=='OK' for r in evaluated)
    summary={'gerado_em_utc':datetime.now(timezone.utc).isoformat(),'datasets':len(data),'registros':sum(len(x) for x in data.values()),'colunas':sum(len(x.columns) for x in data.values()),'regras_avaliadas':len(evaluated),'regras_aprovadas':passed,'regras_reprovadas':len(evaluated)-passed,'conformidade_regras_pct':round(100*passed/len(evaluated),2) if evaluated else None,'ocorrencias':len(issues),'aviso':'Metrica operacional de regras; nao representa conformidade LGPD nem maturidade de governanca.'}
    (output/'resumo.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False),encoding='utf-8')
    return summary

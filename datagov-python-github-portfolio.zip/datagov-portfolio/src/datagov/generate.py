"""Deterministic, fully synthetic relational datasets. No real personal data."""
from pathlib import Path
import random
import pandas as pd

def cpf_for(n:int)->str:
    s=f'{n:09d}'
    for length in (9,10):
        d=(sum(int(s[i])*(length+1-i) for i in range(length))*10)%11
        s+=str(0 if d==10 else d)
    return s

def generate(path:Path,n:int=3000,seed:int=42):
    rng=random.Random(seed);path=Path(path);path.mkdir(parents=True,exist_ok=True)
    cities=['Rio de Janeiro','Niterói','São Paulo','Belo Horizonte','Curitiba','Recife','Salvador','Fortaleza','Brasília','Porto Alegre']
    clients=[]
    for i in range(1,n+1):
        clients.append({'id_cliente':i if i!=11 else 10,'nome':f'Pessoa Sintetica {i:05d}' if i%31 else None,'cpf':cpf_for(i+10000) if i%29 else '00000000000','email':f'cliente{i}@example.test' if i%37 else 'email-invalido','telefone':f'219{(i*137)%100000000:08d}','idade':rng.randint(18,85) if i%53 else 150,'cidade':rng.choice(cities),'cep':f'{20000000+i%7000000:08d}','data_cadastro':f'2025-{1+i%12:02d}-{1+i%28:02d}','canal_origem':rng.choice(['app','web','loja','parceiro']),'consentimento_marketing':rng.choice(['sim','nao','nao_informado'])})
    orders=[]
    for i in range(1,n*2+1):
        orders.append({'id_pedido':i,'id_cliente':rng.randint(1,n) if i%47 else n+999,'data_pedido':f'2026-{1+i%10:02d}-{1+i%28:02d}','valor_total':round(rng.uniform(10,3000),2) if i%41 else -25,'status_pedido':rng.choice(['novo','pago','cancelado','enviado']),'canal_venda':rng.choice(['app','web','loja'])})
    payments=[]
    for i in range(1,n*2+1):payments.append({'id_pagamento':i,'id_pedido':i if i%59 else n*2+77,'valor_pago':orders[i-1]['valor_total'] if i%43 else -12,'metodo_pagamento':rng.choice(['pix','cartao','boleto']),'status_pagamento':rng.choice(['aprovado','pendente','estornado'])})
    tickets=[]
    for i in range(1,n//2+1):tickets.append({'id_atendimento':i,'id_cliente':rng.randint(1,n),'data_abertura':f'2026-{1+i%10:02d}-{1+i%28:02d}','tipo':rng.choice(['duvida','reclamacao','solicitacao']),'prioridade':rng.choice(['baixa','media','alta']),'resolvido':rng.choice([True,False])})
    datasets={'clientes':pd.DataFrame(clients),'pedidos':pd.DataFrame(orders),'pagamentos':pd.DataFrame(payments),'atendimentos':pd.DataFrame(tickets)}
    for name,df in datasets.items():df.to_csv(path/f'{name}.csv',index=False,encoding='utf-8-sig')
    return datasets

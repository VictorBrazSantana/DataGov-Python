import argparse
from pathlib import Path
import pandas as pd
from .generate import generate
from .core import analyze

def main():
    parser=argparse.ArgumentParser(description='DataGov: synthetic data governance portfolio')
    parser.add_argument('--generate',action='store_true',help='Generate synthetic datasets')
    parser.add_argument('--rows',type=int,default=3000)
    parser.add_argument('--data-dir',default='data')
    parser.add_argument('--output-dir',default='reports')
    args=parser.parse_args()
    if args.rows<1:parser.error('--rows must be positive')
    data_dir=Path(args.data_dir)
    if args.generate:generate(data_dir,args.rows)
    paths=sorted(data_dir.glob('*.csv'))
    if not paths:parser.error('No CSV files found. Use --generate.')
    data={p.stem:pd.read_csv(p,dtype={'cpf':'string','cep':'string','telefone':'string'}) for p in paths}
    summary=analyze(data,Path(args.output_dir))
    for k,v in summary.items():print(f'{k}: {v}')
if __name__=='__main__':main()

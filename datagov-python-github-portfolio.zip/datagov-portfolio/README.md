# DataGov Python | Data Governance & Quality Engineering

**Projeto demonstrativo de engenharia de governança de dados com Python.** Converte um notebook exploratório em pipeline reprodutível, testado e publicável. Dados **100% sintéticos**, sem CPFs, e-mails ou pessoas reais.

## Demonstração

- **4 datasets relacionais**: clientes, pedidos, pagamentos e atendimentos
- **3.000 clientes sintéticos** + 6.000 pedidos + 6.000 pagamentos + 1.500 atendimentos por padrão
- Dados intencionalmente imperfeitos para testar qualidade: duplicidade de chave, nulos, e-mails/CPFs inválidos, idade fora de faixa, valores negativos e chaves estrangeiras inexistentes
- Relatórios CSV de profiling, catálogo, regras, ocorrências, ativos e linhagem; resumo JSON
- CI com GitHub Actions e testes pytest

## Instalação e execução

```bash
python -m pip install -e '.[dev]'
python -m datagov --generate --rows 3000
python -m pytest -q
```

Relatórios ficam em `reports/`. Para analisar CSVs próprios, coloque-os em `data/` e execute `python -m datagov` (sem `--generate`). **Não publique dados reais ou pessoais no repositório.** Os validadores e relacionamentos são demonstrativos e podem exigir adaptação ao esquema real.

## Etapas do pipeline

| Etapa | O que faz | Artefato |
|---|---|---|
| 1. Geração/ingestão | Produz bases sintéticas relacionais ou carrega CSVs locais | `data/*.csv` |
| 2. Profiling | Tipos, nulos, distintos, duplicidade de valores, completude | `perfil.csv` |
| 3. Qualidade | Regras de obrigatoriedade, CPF, e-mail, idade, valores e unicidade de chaves | `regras_qualidade.csv` |
| 4. Integridade | Valida relacionamento entre clientes, pedidos, pagamentos e atendimentos | `regras_qualidade.csv` |
| 5. Classificação | Indica categorias potencialmente pessoais por nome do campo | `catalogo.csv` |
| 6. Metadados | Domínio, proprietário, steward, finalidade, base legal, retenção, acesso (pendentes de validação) | `catalogo.csv` |
| 7. Rastreabilidade | Registra origem, destino e operação realmente executada no pipeline | `linhagem.csv` |
| 8. Auditoria | Localiza linha, campo, regra e natureza da ocorrência sem divulgar valor sensível | `problemas.csv` |
| 9. Indicadores | Agrega regras e ocorrências, sem alegar conformidade LGPD | `resumo.json` |

## Limites e decisões de governança

**Importante:** classificação automática é indicativa e exige revisão humana. `A DEFINIR` e `A AVALIAR` são pendências, não evidência de controles. CPF sintético válido nos dígitos verificadores não é identidade real. CNPJ não é automaticamente dado pessoal. Um score de regras aprovadas **não mede** conformidade legal, privacidade, risco residual ou maturidade institucional. Linhagem representa somente as operações observadas neste projeto, não integrações externas imaginadas.

## Evoluções recomendadas

Políticas de acesso RBAC/ABAC, matriz RACI, contratos de dados, versionamento de schemas, SLAs/SLOs, observabilidade e alertas, tratamento de incidentes, avaliação de impacto à proteção de dados quando cabível, registro de operações de tratamento, revisão de bases legais e retenção, fluxo de direitos dos titulares, avaliação de terceiros, testes de drift e documentação de decisões.

## Publicação no GitHub

Crie um repositório público, extraia este projeto, execute testes e pipeline, confira que apenas dados sintéticos estejam presentes, adicione imagens de um dashboard próprio (opcional) e publique com descrição: **"Data Governance & Data Quality Pipeline | Python, pandas, LGPD-aware metadata, CI/CD"**. Nunca apresente este projeto como auditoria real ou certificação LGPD.

## Tecnologias

Python, pandas, pytest, GitHub Actions, CSV/JSON. Sem dependência de serviços externos.

## Licença

MIT (veja LICENSE).

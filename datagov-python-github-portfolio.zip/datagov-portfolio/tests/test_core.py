import pandas as pd
from datagov.core import cpf_valid,analyze
from datagov.generate import cpf_for,generate

def test_cpf():
    assert cpf_valid(cpf_for(12345))
    assert not cpf_valid('11111111111')
    assert not cpf_valid('12345678901')

def test_generation_and_pipeline(tmp_path):
    data=generate(tmp_path/'data',100)
    result=analyze(data,tmp_path/'reports')
    assert result['datasets']==4
    assert result['regras_reprovadas']>0
    assert (tmp_path/'reports'/'catalogo.csv').exists()
    assert not any('Pessoa Sintetica' in x for x in (tmp_path/'reports'/'catalogo.csv').read_text())

def test_empty_dataset(tmp_path):
    result=analyze({'clientes':pd.DataFrame({'id_cliente':pd.Series(dtype='int64')})},tmp_path/'reports')
    assert result['conformidade_regras_pct']==0
